
# Mind Maze

This is a game inspired by The Password Game, where players will have to go through bizarre rules to create a final password that satisfies all to pass the game.

## Authors

- [@Vezyldicode](https://www.github.com/vezyldicode)

